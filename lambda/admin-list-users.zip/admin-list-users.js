// Lambda: Admin list customers (returns sub, email)
// Runtime: nodejs18.x (or higher), uses AWS SDK v2 built-in
const AWS = require('aws-sdk');
const cognito = new AWS.CognitoIdentityServiceProvider();

exports.handler = async (event) => {
  console.log('admin-list-users event:', JSON.stringify(event, null, 2));

  const userPoolId = process.env.USER_POOL_ID || 'us-east-1_dskUsnKt3';
  const groupName = process.env.CUSTOMER_GROUP || 'customer';
  const limit = parseInt(process.env.PAGE_SIZE || '60', 10);

  try {
    const query = event.queryStringParameters || {};
    const token = query.nextToken;

    const res = await cognito.listUsersInGroup({
      UserPoolId: userPoolId,
      GroupName: groupName,
      Limit: limit,
      NextToken: token,
    }).promise();

    const users = (res.Users || [])
      .map((u) => ({
        sub: u.Attributes?.find((a) => a.Name === 'sub')?.Value,
        email: u.Attributes?.find((a) => a.Name === 'email')?.Value,
      }))
      .filter((u) => u.sub);

    return {
      statusCode: 200,
      body: JSON.stringify({
        users,
        nextToken: res.NextToken || null,
      }),
    };
  } catch (err) {
    console.error('Error listing users:', err);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: err.message || 'Internal error' }),
    };
  }
};

